import 'dart:async';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class WeatherScreen extends StatefulWidget {
  const WeatherScreen({Key? key}) : super(key: key);

  @override
  _WeatherScreenState createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _backgroundImage = 'assets/images/day.jpg'; // Default to day image
  bool _showSearchField = false;
  final PageController _pageController = PageController();
  List<DocumentSnapshot> _weatherPages = [];

  @override
  void initState() {
    super.initState();
    _updateBackgroundImage(); // Initial background image based on time
    _fetchWeatherPages();
  }

  String _formatTime(int timestamp) {
    final date = DateTime.fromMillisecondsSinceEpoch(timestamp * 1000);
    final timeFormat = DateFormat('hh:mm a'); // Adjust the time format as needed
    return timeFormat.format(date);
  }

  Future<void> _fetchWeatherData(String city) async {
    final apiKey = '23e6ebdba97233c1ee51a166a9d2d1e5'; // Replace with your API key
    final apiUrl = 'https://api.openweathermap.org/data/2.5/forecast?q=$city&appid=$apiKey';

    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      final decodedData = json.decode(response.body);

      await FirebaseFirestore.instance.collection('weatherData').add({
        'city': city,
        'data': decodedData,
      });
    } else {
      throw Exception('Failed to load weather data');
    }
  }

  void _fetchWeatherPages() {
    FirebaseFirestore.instance.collection('weatherData').get().then((snapshot) {
      setState(() {
        _weatherPages = snapshot.docs;
      });
    });
  }

  void _updateBackgroundImage() {
    final currentTime = DateTime.now();
    final sunrise = DateTime(currentTime.year, currentTime.month, currentTime.day, 6, 0);
    final sunset = DateTime(currentTime.year, currentTime.month, currentTime.day, 18, 0);

    if (currentTime.isAfter(sunrise) && currentTime.isBefore(sunset)) {
      setState(() {
        _backgroundImage = 'assets/images/day.jpg'; // Daytime image
      });
    } else {
      setState(() {
        _backgroundImage = 'assets/images/night.jpg'; // Nighttime image
      });
    }
  }
Widget _buildWeatherCard(dynamic weatherData, String city) {
    if (weatherData == null || weatherData['list'] == null) {
      return Container(); // You can display a loading indicator here.
    }

    final List<dynamic> forecastList = weatherData['list'];

    // Filter the forecast to only show the next 24 hours, with a 1-hour interval
    final DateTime now = DateTime.now();
    final DateTime twentyFourHoursLater = now.add(Duration(hours: 24));
    final filteredForecastList = forecastList.where((forecast) {
      final timestamp = forecast['dt'] * 1000;
      final date = DateTime.fromMillisecondsSinceEpoch(timestamp);
      return date.isAfter(now) &&
          date.isBefore(twentyFourHoursLater) &&
          date.hour % 1 == 0;
    }).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                city,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              Text(
                DateFormat('EEEE, MMM d').format(DateTime.now()),
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
              SizedBox(height: 16),
              Row(
                children: [
                  Text(
                    '${(filteredForecastList[0]['main']['temp'] - 273.15).toStringAsFixed(1)}°C',
                    style: TextStyle(
                      fontSize: 48,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        filteredForecastList[0]['weather'][0]['main'],
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(Icons.location_on, size: 16),
                          Text(
                            city,
                            style: TextStyle(
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: filteredForecastList.map<Widget>((forecast) {
              final timestamp = forecast['dt'] * 1000;
              final date = DateTime.fromMillisecondsSinceEpoch(timestamp);
              final temp =
                  (forecast['main']['temp'] - 273.15).toStringAsFixed(1);
              final iconCode = forecast['weather'][0]['icon'];
              final hour = DateFormat('h a').format(date);

              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Text(
                      hour,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Image.network(
                      'https://openweathermap.org/img/w/$iconCode.png',
                      width: 50,
                      height: 50,
                    ),
                    SizedBox(height: 8),
                    Text(
                      '$temp°C',
                      style: TextStyle(
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
        SizedBox(height: 16),
        Container(
          height: 150,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: filteredForecastList.length,
            itemBuilder: (context, index) {
              final forecast = filteredForecastList[index];
              final timestamp = forecast['dt'] * 1000;
              final date = DateTime.fromMillisecondsSinceEpoch(timestamp);
              final temp =
                  (forecast['main']['temp'] - 273.15).toStringAsFixed(1);
              final iconCode = forecast['weather'][0]['icon'];
              final day = DateFormat('EEEE').format(date);
              return Container(
                width: 150,
                child: Card(
                  elevation: 4.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Text(
                          day,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 8),
                        Image.network(
                          'https://openweathermap.org/img/w/$iconCode.png',
                          width: 50,
                          height: 50,
                        ),
                        SizedBox(height: 8),
                        Text(
                          '$temp°C',
                          style: TextStyle(
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),],);}




  void _addWeatherPage() {
    final location = _searchController.text;
    _fetchWeatherData(location).then(() {
      _searchController.clear();
      _showSearchField = false;
      _fetchWeatherPages();
    } as FutureOr Function(void value));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 4,
        title: _showSearchField
            ? TextField(
          controller: _searchController,
          decoration: InputDecoration(
            hintText: 'Enter location',
            suffixIcon: IconButton(
              icon: const Icon(Icons.clear),
              onPressed: () {
                setState(() {
                  _searchController.clear();
                  _showSearchField = false;
                });
              },
            ),
          ),
          onSubmitted: (value) {
            _addWeatherPage();
          },
        )
            : const Text('Weather App'),
        actions: [
          IconButton(
            icon: Icon(_showSearchField ? Icons.close : Icons.search),
            onPressed: () {
              setState(() {
                _showSearchField = !_showSearchField;
                if (!_showSearchField) {
                  _searchController.clear();
                }
              });
            },
          ),
          if (!_showSearchField)
            IconButton(
              icon: const Icon(Icons.add),
              onPressed: () {
                _addWeatherPage();
              },
            ),
          if (!_showSearchField && _weatherPages.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () {
                final documentId = _weatherPages[_pageController.page!.toInt()].id;
                FirebaseFirestore.instance
                    .collection('weatherData')
                    .doc(documentId)
                    .delete()
                    .then((_) {
                  setState(() {
                    _weatherPages.removeAt(_pageController.page!.toInt());
                  });
                });
              },
            ),
        ],
      ),
      body: Stack(
        children: [
          Image.asset(
            _backgroundImage,
            fit: BoxFit.cover,
            height: double.infinity,
            width: double.infinity,
          ),
          PageView.builder(
            controller: _pageController,
            itemCount: _weatherPages.length,
            onPageChanged: (index) {
              setState(() {
                _searchController.clear();
                _showSearchField = false;
              });
            },
            itemBuilder: (context, index) {
              final weatherData = _weatherPages[index].data() as Map<String, dynamic>;
              final city = weatherData['city'];
              return Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _buildWeatherCard(
                    weatherData['data'],
                    city,
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}
